window.document$.subscribe(() => {
    hljs.highlightAll();
});
