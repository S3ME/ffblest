<?= $this->extend('office/layout') ?>

<?= $this->section('main') ?>
<?= $this->endSection() ?>